package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import java.util.List;

public class LoginPage {

    @FindBy(how = How.CLASS_NAME, using = "login-ebank-image")
    WebElement loginImageElement;

    @FindBy(how = How.CLASS_NAME, using = "input-label")
    List<WebElement> labelElements;

    @FindBy(how = How.CLASS_NAME, using = "login-heading")
    WebElement loginHeadingElement;

    @FindBy(how = How.ID, using = "userIdInput")
    WebElement userIdInputElement;

    @FindBy(how = How.ID, using = "pinInput")
    WebElement pinInputElement;

    @FindBy(how = How.CLASS_NAME, using = "login-button")
    WebElement loginButtonElement;

    @FindBy(how = How.CLASS_NAME, using = "error-message-text")
    WebElement errorMessageElement;

    WebDriver driver;
    WebDriverWait wait;


    public LoginPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        PageFactory.initElements(driver, this);
    }

    public WebElement findLoginImageElement() {
        return loginImageElement;
    }

    public String getLabelTextAt(int index) {
        return labelElements.get(index).getText();
    }

    public String getLoginHeadingText() {
        return loginHeadingElement.getText();
    }

    public void enterUserId(String userId){
        userIdInputElement.sendKeys(userId);
    }

    public void enterPin(String pin){
        pinInputElement.sendKeys(pin);
    }

    public void clickOnLoginButton() {
        loginButtonElement.click();
    }

    public void loginToApplication(String userId, String pin){
        enterUserId(userId);
        enterPin(pin);
        clickOnLoginButton();
    }

    public String getErrorMessage() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("error-message-text")));
        return errorMessageElement.getText();
    }
}