package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {

    @FindBy(className = "ebank-logo")
    WebElement appLogoElement;

    @FindBy(className = "heading")
    WebElement headingElement;

    @FindBy(className = "digital-card-image")
    WebElement digitalCardImageElement;

    @FindBy(className = "logout-button")
    WebElement logoutButtonElement;

    WebDriver driver;

    public HomePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public WebElement findAppLogo() {
        return appLogoElement;
    }

    public WebElement findDigitalCard() {
        return digitalCardImageElement;
    }

    public String getHeadingText() {
        return headingElement.getText();
    }

    public void clickOnLogoutButton(){
        logoutButtonElement.click();
    }
}